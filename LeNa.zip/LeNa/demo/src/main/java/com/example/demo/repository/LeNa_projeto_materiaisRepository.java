package com.example.demo.repository;

import com.example.demo.models.LeNa_projeto_materiais;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeNa_projeto_materiaisRepository extends JpaRepository<LeNa_projeto_materiais, Long> {
}
