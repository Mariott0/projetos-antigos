package com.example.demo.repository;

import com.example.demo.models.LeNa_materiais;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LeNa_materiaisRepository extends JpaRepository<LeNa_materiais, Long> {
}
