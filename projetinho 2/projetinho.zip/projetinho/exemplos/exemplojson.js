

const dado = {
    "nome": "joao",
    "lista": [{
        "nome": "pedro"
    }]
}

console.log(dado.lista)

const outrodado = [
    'joao',
    'maria',
    true,
    10.0,
    false,
    new Date(),
    1 + 2,
    'a' + 'b'
]

console.log(outrodado)