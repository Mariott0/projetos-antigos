const Calculadora = require('./calculadora')

console.log(
    Calculadora.divisao(10, 2)
)