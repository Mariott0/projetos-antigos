
class Calculadora {

    static soma(a, b) {
        return a + b
    }
    static divisao(a, b) {
        return a / b
    }
}

module.exports = Calculadora